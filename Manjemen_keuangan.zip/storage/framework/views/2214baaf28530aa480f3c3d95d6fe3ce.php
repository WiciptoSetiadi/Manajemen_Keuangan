<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans text-slate-900 antialiased bg-slate-50">
        <?php
            $isLogin = request()->routeIs('login');
        ?>

        <div class="min-h-screen">
            <div class="mx-auto grid min-h-screen max-w-7xl grid-cols-1 lg:grid-cols-[1.3fr_1fr]">
                <div class="hidden lg:flex flex-col justify-center gap-10 px-8 py-16 bg-gradient-to-br from-teal-700 via-teal-600 to-cyan-700 text-white">
                    <div class="flex items-center gap-3">
                        <div class="rounded-2xl bg-white/10 p-3 shadow-lg shadow-black/10">
                            <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'w-12 h-12 text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-12 h-12 text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <p class="text-sm uppercase tracking-[0.25em] font-semibold text-teal-100/80">Smart Expense</p>
                        </div>
                    </div>

                    <div class="max-w-lg space-y-6">
                        <h1 class="text-4xl font-semibold tracking-tight">Institutional-grade security for your personal wealth.</h1>
                        <p class="text-sm leading-7 text-teal-100/90">Join thousands of professional traders and high-net-worth individuals who trust Smart Expense Manager for stable, precise financial tracking.</p>
                    </div>

                    <div class="space-y-4 text-sm text-teal-100/90">
                        <div class="flex items-start gap-3">
                            <span class="mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-white/15 text-teal-50">
                                ✓
                            </span>
                            <span>Bank-level 256-bit encryption</span>
                        </div>
                        <div class="flex items-start gap-3">
                            <span class="mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-white/15 text-teal-50">
                                ✓
                            </span>
                            <span>Multi-factor authentication required</span>
                        </div>
                        <div class="flex items-start gap-3">
                            <span class="mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-white/15 text-teal-50">
                                ✓
                            </span>
                            <span>SOC 2 Type II Certified Infrastructure</span>
                        </div>
                    </div>
                </div>

                <div class="flex items-center justify-center px-6 py-12">
                    <div class="w-full max-w-xl rounded-[32px] border border-slate-200/70 bg-white/95 p-8 shadow-2xl shadow-slate-900/10 backdrop-blur-xl">
                        <div class="mb-8 flex flex-col gap-6">
                            <div class="flex items-center justify-between gap-4">
                                <div>
                                    <p class="text-sm font-medium uppercase tracking-[0.22em] text-slate-500"><?php echo e($isLogin ? 'Sign In' : 'Create Account'); ?></p>
                                    <h2 class="mt-3 text-3xl font-semibold text-slate-900"><?php echo e($isLogin ? 'Welcome back' : 'Create your account'); ?></h2>
                                    <p class="mt-3 text-sm leading-6 text-slate-500"><?php echo e($isLogin ? 'Enter your credentials to access your portfolio.' : 'Start building your portfolio with a secure account.'); ?></p>
                                </div>
                            </div>

                            <div class="flex items-center gap-2 overflow-hidden rounded-full bg-slate-100 p-1 text-sm font-semibold text-slate-500 shadow-sm">
                                <a href="<?php echo e(route('login')); ?>" wire:navigate class="inline-flex flex-1 items-center justify-center rounded-full px-4 py-3 transition-colors duration-200 <?php echo e($isLogin ? 'bg-white text-slate-900 shadow-sm' : 'hover:bg-slate-200'); ?>">Sign In</a>
                                <a href="<?php echo e(route('register')); ?>" wire:navigate class="inline-flex flex-1 items-center justify-center rounded-full px-4 py-3 transition-colors duration-200 <?php echo e(! $isLogin ? 'bg-white text-slate-900 shadow-sm' : 'hover:bg-slate-200'); ?>">Create Account</a>
                            </div>
                        </div>

                        <div class="space-y-6">
                            <?php echo e($slot); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\laragon\www\Manajemen_Keuanganv1\resources\views/layouts/guest.blade.php ENDPATH**/ ?>