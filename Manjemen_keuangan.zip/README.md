# Smart Expense - Wealth Management Dashboard

## Setup Guide

1. composer install
2. npm install
3. cp .env.example .env
4. php artisan key:generate
5. php artisan migrate
6. php artisan migrate --seed
7. php artisan serve (terminal 1)
8. npm run dev (terminal 2)

A full-stack Laravel web application that replicates the "Smart Expense" Figma design, featuring a modern, responsive user dashboard and a robust backend admin panel.

## Features

*   **Modern UI/UX**: Built with Tailwind CSS, strictly following the provided Figma design with a focus on clean aesthetics, proper spacing, and the Inter typography.
*   **User Dashboard**: Includes dynamic data visualization for Net Worth, Savings Goals, and Recent Transactions.
*   **Role-Based Authentication**: Separate access for regular users (Dashboard) and administrators (Filament Admin Panel).
*   **Admin Panel**: Built with Filament PHP for comprehensive management of users, transactions, categories, budgets, and savings goals.
*   **Optimized Queries**: Efficient Eloquent relationships and eager loading to ensure fast page loads.

## Tech Stack

*   **Backend**: Laravel 11.x, PHP 8.2+
*   **Frontend**: Blade, Livewire, Alpine.js, Tailwind CSS
*   **Icons**: Heroicons (`blade-ui-kit/blade-heroicons`)

## Installation & Setup

1.  **Clone the Repository** (If applicable, or navigate to the project directory)
    ```bash
    cd c:\laragon\www\ManajemenKeauangan
    ```

2.  **Install Dependencies**
    ```bash
    composer install
    npm install
    ```

3.  **Environment Setup**
    Copy `.env.example` to `.env` (if not already done).
    ```bash
    cp .env.example .env
    php artisan key:generate
    ```

4.  **Database Migration & Seeding**
    The seeder will populate the database with categories, dummy transactions, and default users.
    ```bash
    php artisan migrate:fresh --seed
    ```

5.  **Compile Frontend Assets**
    ```bash
    npm run build
    ```

6.  **Run the Development Server**
    ```bash
    php artisan serve
    ```

## Default Accounts

*   **Admin User** (Access to `/admin` and `/dashboard`):
    *   Email: `admin@example.com`
    *   Password: `password`
*   **Regular User** (Access to `/dashboard` only):
    *   Email: `professional@example.com`
    *   Password: `password`

## Project Structure Highlights

*   `app/Models/*` - Eloquent models with relationships defined.
*   `app/Filament/Resources/*` - Filament resources for admin management.
*   `database/migrations/*` - Database schema definitions.
*   `database/seeders/DatabaseSeeder.php` - Dummy data generation.
*   `resources/views/dashboard.blade.php` - The main dashboard UI replicating the Figma design.
*   `resources/views/layouts/app.blade.php` - The main application layout including the sidebar and top navigation.
*   `tailwind.config.js` - Custom brand colors and typography setup.
